'''
Green Screen
This program allows you to replace a green screen picture with any picture as the background. The two images has to be the same file type
Created by: Richard Cao
Created on: 05/02/2022
Last modified: 05/02/2022
'''

size(640,360)
#Allow the computer to acknowledge that the images exist
img = loadImage("istockphoto-520933004-640x640.jpg")
backgroundImg = loadImage("iStock-1300845179.jpg")
image (img,0,0)
#640,360
# 788,443

#Variable x is the difference between the width of the bigger image and the smalller image
x = backgroundImg.width - img.width

#Create 1-D arrays for the img and backgroundImg that will be used for indexinng
img.loadPixels()
backgroundImg.loadPixels()
# Green Colour: 22,255,36


for i in range(len(img.pixels)):

    #Set each variable to be the value of red,green, and blue of the green screen    
    imgRed = red(img.pixels[i])
    imgGreen = green(img.pixels[i])
    imgBlue = blue(img.pixels[i])
    
    #The row of the pixel indexes 
    row = i//640
    
    if 8 < imgRed < 180 and 195 < imgGreen <= 255 and 15 < imgBlue < 170:
    #The pixel in the smaller image at index i will be replace by the pixel in the larger image at index i + the difference of width * the row number
       img.pixels[i] = backgroundImg.pixels[i + x*row]            
         
#Update and save the new image
img.updatePixels()
image(img,0,0)